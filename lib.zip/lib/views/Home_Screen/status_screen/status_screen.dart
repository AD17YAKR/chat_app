import 'package:flutter/material.dart';

class Status_screen extends StatefulWidget {
  const Status_screen({Key? key}) : super(key: key);

  @override
  State<Status_screen> createState() => _Status_screenState();
}

class _Status_screenState extends State<Status_screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
