import 'package:stacked/stacked.dart';

class ChatScreenViewModel extends BaseViewModel {}
