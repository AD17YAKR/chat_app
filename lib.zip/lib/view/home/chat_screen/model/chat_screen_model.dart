class User {
  int? index;
  String? name;

  User(this.index, this.name);
}
